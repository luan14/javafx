package entidades;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Aluno {
	private IntegerProperty id;
	private StringProperty nome;
	private StringProperty email;
	private StringProperty nascimento;
	private StringProperty cpf;
	private StringProperty fone;
	private StringProperty endereco;

	public Aluno(String nome) {
		this.nome = new SimpleStringProperty(nome);
		this.email = new SimpleStringProperty();
		this.nascimento = new SimpleStringProperty();
		this.id = new SimpleIntegerProperty();
		this.cpf = new SimpleStringProperty();
		this.fone = new SimpleStringProperty();
		this.endereco = new SimpleStringProperty();
	}

	public final IntegerProperty idProperty() {
		return this.id;
	}

	public final int getid() {
		return this.idProperty().get();
	}

	public final void setCodigo(final int id) {
		this.idProperty().set(id);
	}

	public final StringProperty nomeProperty() {
		return this.nome;
	}

	public final String getNome() {
		return this.nomeProperty().get();
	}

	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}

	public final StringProperty emailProperty() {
		return this.email;
	}

	public final String getEmail() {
		return this.emailProperty().get();
	}

	public final void setEmail(final String email) {
		this.emailProperty().set(email);
	}

	public final StringProperty nascimentoProperty() {
		return this.nascimento;
	}

	public final String getNascimento() {
		return this.nascimentoProperty().get();
	}

	public final void setNascimento(final String nascimento) {
		this.nascimentoProperty().set(nascimento);
	}

	public final StringProperty cpfProperty() {
		return this.cpf;
	}

	public final String getCpf() {
		return this.cpfProperty().get();
	}

	public final void setCpf(final String cpf) {
		this.cpfProperty().set(cpf);
	}

	public final StringProperty foneProperty() {
		return this.fone;
	}

	public final String getFone() {
		return this.foneProperty().get();
	}

	public final void setFone(final String fone) {
		this.foneProperty().set(fone);
	}

	public final StringProperty enderecoProperty() {
		return this.endereco;
	}

	public final String getEndereco() {
		return this.enderecoProperty().get();
	}

	public final void setEndereco(final String endereco) {
		this.enderecoProperty().set(endereco);
	}

}
