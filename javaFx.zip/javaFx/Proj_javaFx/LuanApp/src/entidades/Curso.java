package entidades;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Curso {

	private IntegerProperty id;
	private StringProperty nome;
	private StringProperty requisito;
	private IntegerProperty carga_horaria;
	private SimpleDoubleProperty preco;
	private IntegerProperty Fk_aluno;

	public Curso(String nome) {
		this.nome = new SimpleStringProperty(nome);
		this.requisito = new SimpleStringProperty();
		this.carga_horaria = new SimpleIntegerProperty();
		this.preco = new SimpleDoubleProperty();
		this.Fk_aluno = new SimpleIntegerProperty();

	}

	public final IntegerProperty idProperty() {
		return this.id;
	}

	public final int getId() {
		return this.idProperty().get();
	}

	public final void setId(final int id) {
		this.idProperty().set(id);
	}

	public final StringProperty nomeProperty() {
		return this.nome;
	}

	public final String getNome() {
		return this.nomeProperty().get();
	}

	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}

	public final StringProperty requisitoProperty() {
		return this.requisito;
	}

	public final String getRequisito() {
		return this.requisitoProperty().get();
	}

	public final void setRequisito(final String requisito) {
		this.requisitoProperty().set(requisito);
	}

	public final IntegerProperty carga_horariaProperty() {
		return this.carga_horaria;
	}

	public final int getCarga_horaria() {
		return this.carga_horariaProperty().get();
	}

	public final void setCarga_horaria(final int string) {
		this.carga_horariaProperty().set(string);
	}

	public final DoubleProperty precoProperty() {
		return this.preco;
	}

	public final double getPreco() {
		return this.precoProperty().get();
	}

	public final void setPreco(final double preco) {
		this.precoProperty().set(preco);
	}

	public final IntegerProperty Fk_alunoProperty() {
		return this.Fk_aluno;
	}

	public final int getFk_aluno() {
		return this.Fk_alunoProperty().get();
	}

	public final void setFk_aluno(final int Fk_aluno) {
		this.Fk_alunoProperty().set(Fk_aluno);
	}

}
