package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import entidades.Aluno;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AlunoDAO {
	// Estrutura de Dados
	private ObservableList<Aluno> listaAlunos = FXCollections.observableArrayList();;

	public AlunoDAO() {
		// listaPessoas=FXCollections.observableArrayList();
	}

	public void inserir(Aluno a) {
		Conexao con = new Conexao();
		try {
			String sql = "INSERT INTO aluno " + "(nome, cpf, endereco,  fone, nascimento , email ) "
					+ "VALUES (?,?,?,?,?,?)";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setString(1, a.getNome());
			prep.setString(2, a.getCpf());
			prep.setString(3, a.getEndereco());
			prep.setString(4, a.getFone());
			prep.setString(5, a.getNascimento());
			prep.setString(6, a.getEmail());
			
			prep.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
	}

	public void alterar(Aluno a) {
		Conexao con = new Conexao();
		try {
			String sql = "UPDATE aluno SET "
					+ "nome = ?,  cpf  = ?, endereco = ? ,fone = ? , nascimento = ? , email = ?" + "WHERE id = ?";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setString(1, a.getNome());
			prep.setString(2, a.getCpf());
			prep.setString(3, a.getEndereco());
			prep.setString(4, a.getFone());
			prep.setString(5, a.getNascimento());
			prep.setString(6, a.getEmail());
			
			prep.setInt(7, a.getid());

			prep.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
	}

	public void excluir(Aluno a) {
		Conexao con = new Conexao();
		try {
			String sql = "DELETE FROM aluno " + "WHERE id = ?";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setInt(1, a.getid());
			((PreparedStatement) prep).executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
	}

	public ObservableList<Aluno> listar() {
		Conexao con = new Conexao();
		try {
			String sql = "SELECT * FROM aluno " + "ORDER BY nome";
			Statement prep = con.getConexao().createStatement();
			ResultSet res = prep.executeQuery(sql);
			while (res.next()) {
				// instancia o objeto pessoa pegando o seu nome do bd
				Aluno a = new Aluno(res.getString("nome"));
				// atribui os valores ao objeto de entidade buscando os dados no bd
				a.setCodigo(res.getInt("id"));
				a.setEmail(res.getString("email"));
				a.setNascimento(res.getString("nascimento"));
				a.setCpf(res.getString("cpf"));
				a.setFone(res.getString("fone"));
				a.setEndereco(res.getString("endereco"));
				listaAlunos.add(a);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
		return listaAlunos;

		
	}

	// SIMULAR CONSULTA DE ELEMENTOS
	public ObservableList<Aluno> getListaAluno() {
		
		return listar();
		
	}
	
	 /*private void criaAluno() { Aluno p1 = new Aluno("Maria");
	 *p1.setCodigo(1); p1.setEmail("maria@libertas.edu.br"); p1.setNascimento("20");
	  
	  *Aluno p2 = new Aluno("Jos�"); p2.setCodigo(2);
	  *p2.setEmail("jose@libertas.edu.br"); p2.setNascimento("22"); listaAlunos.add(p1);
	 /* listaAlunos.add(p2); }
	 /*/
}
