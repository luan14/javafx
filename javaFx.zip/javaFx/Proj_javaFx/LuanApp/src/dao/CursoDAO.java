package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import entidades.Aluno;
import entidades.Curso;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CursoDAO {

	private ObservableList<Curso> listaCursos = FXCollections.observableArrayList();;

	public CursoDAO() {

	}

	public void inserir(Curso c) {
		Conexao con = new Conexao();
		try {
			String sql = "INSERT INTO curso " + "(nome, Requisito, Carga_horaria, Preco, Fk_aluno ) "
					+ "VALUES (?,?,?,?,?)";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setString(1, c.getNome());
			prep.setString(2, c.getRequisito());
			prep.setInt(3, c.getCarga_horaria());
			prep.setDouble(4, c.getPreco());
			prep.setInt(5, c.getFk_aluno());

			prep.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
	}

	public void alterar(Curso c) {
		Conexao con = new Conexao();
		try {
			String sql = "UPDATE aluno SET " + "Nome = ?, Requisito  = ?, Carga_horaria = ? ,Preco= ? , Fk_aluno = ? "
					+ "WHERE id = ?";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setString(1, c.getNome());
			prep.setString(2, c.getRequisito());
			prep.setInt(3, c.getCarga_horaria());
			prep.setDouble(4, c.getPreco());
			prep.setInt(5, c.getFk_aluno());

			prep.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
	}

	public void excluir(Curso c) {
		Conexao con = new Conexao();
		try {
			String sql = "DELETE FROM curso " + "WHERE id = ?";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setInt(1, c.getId());
			((PreparedStatement) prep).executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
	}

	public ObservableList<Curso> listar() {
		Conexao con = new Conexao();
		try {
			String sql = "SELECT * FROM curso " + "ORDER BY nome";
			Statement prep = con.getConexao().createStatement();
			ResultSet res = prep.executeQuery(sql);
			while (res.next()) {
				Curso c = new Curso(res.getString("nome"));
				c.setId(res.getInt("id"));
				c.setNome(res.getString("nome"));
				c.setRequisito(res.getString("requisito"));
				c.setCarga_horaria(res.getInt("Carga_horaria"));
				c.setPreco(res.getDouble("preco"));
				c.setFk_aluno(res.getInt("Fk_aluno"));
				listaCursos.add(c);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		con.desconecta();
		return listaCursos;

	}

	// SIMULAR CONSULTA DE ELEMENTOS
	public ObservableList<Curso> getListaCurso() {

		return listar();

	}

}
