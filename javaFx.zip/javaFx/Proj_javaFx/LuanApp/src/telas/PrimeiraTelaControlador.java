package telas;

import aplicacao.MainApp;
import dao.AlunoDAO;
import dao.CursoDAO;
import entidades.Aluno;
import entidades.Curso;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class PrimeiraTelaControlador {
	@FXML
	private TableView<Aluno> tabelaAluno;
	//@FXML
	//private TableView<Curso> tabelaCurso;
	@FXML
	private TableColumn<Aluno, Number> colunaCodigo;
	@FXML
	private TableColumn<Aluno, String> colunaNome;
	@FXML
	private TableColumn<Aluno, String> colunaIdade;
	//@FXML
	//private TableColumn<Curso, String> colunaCurso;
	@FXML
	private Label lblNome;
	@FXML
	private Label lblCodigo;
	@FXML
	private Label lblIdade;
	@FXML
	private Label lblEmail;
	@FXML
	private Label lblCpf;
	@FXML
	private Label lblEndereco;
	@FXML
	private Label lblTelefone;
	
	/*@FXML
	private Label lbl_ID;
	@FXML
	private Label lblCnome;
	@FXML
	private Label lblRequisito;
	@FXML
	private Label lblCarga_Horaria;
	@FXML
	private Label lblPreco; 
	@FXML
	private Label lblFK_aluno; 
	

	/*/private MainApp mainApp;
	//private Aluno aluno;

	public PrimeiraTelaControlador() {

	}

	@FXML
	private void initialize() {
		colunaCodigo.setCellValueFactory(c -> c.getValue().idProperty());
		colunaNome.setCellValueFactory(c -> c.getValue().nomeProperty());
		colunaIdade.setCellValueFactory(c -> c.getValue().nascimentoProperty());
		//colunaCurso.setCellValueFactory(c -> c.getValue().nomeProperty());
		// limpar os detalhes
		mostraDetalhes(null);

		// detectar mudan�as na sele��o
		tabelaAluno.getSelectionModel().selectedItemProperty()
				.addListener((observando, valorAntigo, novoValor) -> mostraDetalhes(novoValor));
		
		//tabelaCurso.getSelectionModel().selectedItemProperty()
		//.addListener((observando, valorAntigo, novoValor) -> mostraDetalhesC(novoValor));
	}

	

	public void setMainApp(MainApp mainApp) {
		this.mainApp = mainApp;
		AlunoDAO dao = new AlunoDAO();
		//CursoDAO cao = new CursoDAO();
		tabelaAluno.setItems(dao.getListaAluno());
		//tabelaCurso.setItems(cao.getListaCurso());
		
	}

	@FXML
	private void deletarAluno() {

		int indiceSelecionado = tabelaAluno.getSelectionModel().getSelectedIndex();
		if (indiceSelecionado >= 0) {
			// remove a pessoa do banco de dados
			AlunoDAO pdao = new AlunoDAO();
			pdao.excluir(tabelaAluno.getItems().get(indiceSelecionado));

			tabelaAluno.getItems().remove(indiceSelecionado);
		} else {
			Alert alerta = new Alert(AlertType.WARNING);
			alerta.setTitle("Nenhum registro selecionado");
			alerta.setHeaderText("Nenhuma pessoa selecionada");
			alerta.setContentText("Voc� deve selecionar um registro na tabela");
			alerta.showAndWait();
		}

	}
	
	
	/*/@FXML
	private void deletarCurso() {

		int indiceSelecionado = tabelaCurso.getSelectionModel().getSelectedIndex();
		if (indiceSelecionado >= 0) {
			// remove a pessoa do banco de dados
			CursoDAO pcao = new CursoDAO();
			pcao.excluir(tabelaCurso.getItems().get(indiceSelecionado));

			tabelaCurso.getItems().remove(indiceSelecionado);
		} else {
			Alert alerta = new Alert(AlertType.WARNING);
			alerta.setTitle("Nenhum registro selecionado");
			alerta.setHeaderText("Nenhuma pessoa selecionada");
			alerta.setContentText("Voc� deve selecionar um registro na tabela");
			alerta.showAndWait();
		}
/*/
	//}
	public void mostraDetalhes(Aluno aluno) {
		if (aluno != null) {
			lblNome.setText(aluno.getNome());
			lblIdade.setText(aluno.getNascimento());
			// foi necess�rio converter de int para String
			lblCodigo.setText(String.valueOf(aluno.getid()));
			lblEmail.setText(aluno.getEmail());
			lblCpf.setText(aluno.getCpf());
			lblEndereco.setText(aluno.getEndereco());
			lblTelefone.setText(aluno.getFone());

		} else {
			lblNome.setText("");
			lblIdade.setText("");
			lblCodigo.setText("");
			lblEmail.setText("");
			lblCpf.setText("");
			lblEndereco.setText("");
			lblTelefone.setText("");

		}
	}
		
		/*/public void mostraDetalhesC(Curso curso) {
			if (curso != null) {
				lblCnome.setText(curso.getNome());
				lblRequisito.setText(curso.getRequisito());
				// foi necess�rio converter de int para String
				lblCarga_Horaria.setText(String.valueOf(curso.getCarga_horaria()));
				lblPreco.setText(String.valueOf(curso.getPreco()));
				lblFK_aluno.setText(String.valueOf(curso.getFk_aluno()) );
				lbl_ID.setText(String.valueOf(curso.getId()) );
				

			} else {
				lblCnome.setText("");
				lblRequisito.setText("");
				lblCarga_Horaria.setText("");
				lblPreco.setText("");
				lblFK_aluno.setText("");
				lbl_ID.setText("");

			}

	}
/*/
	@FXML
	private void cliqueNovaAluno() {
		Aluno aluno = new Aluno("");
		mainApp.mostrarAdicionarEditarAluno(aluno);
		// mainApp.getLista().add(pessoa);
		tabelaAluno.getItems().add(aluno);

		// recarrega os dados do BD
		AlunoDAO dao = new AlunoDAO();
		tabelaAluno.setItems(dao.getListaAluno());
		// mostraDetalhes(pessoa);

	}
	
	
	/*@FXML
	private void cliqueNovaCurso() {
		Curso curso = new Curso("");
		mainApp.mostrarAdicionarEditarCurso(curso);
		// mainApp.getLista().add(pessoa);
		tabelaCurso.getItems().add(curso);

		// recarrega os dados do BD
		AlunoDAO dao = new AlunoDAO();
		tabelaAluno.setItems(dao.getListaAluno());
		// mostraDetalhes(pessoa);

	/*///}


	@FXML
	private void cliqueEditarAluno() {
		Aluno aluno = tabelaAluno.getSelectionModel().getSelectedItem();
		if (aluno != null) {
			mainApp.mostrarAdicionarEditarAluno(aluno);
			mostraDetalhes(aluno);
		}
	}

}
