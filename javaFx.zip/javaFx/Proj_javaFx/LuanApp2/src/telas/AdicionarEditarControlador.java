package telas;

import dao.CursoDAO;

import entidades.Curso;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdicionarEditarControlador {

	@FXML
	private TextField txtId;
	@FXML
	private TextField txtCnome;
	@FXML
	private TextField txtRequisito;
	@FXML
	private TextField txtCargaHoraria;
	@FXML
	private TextField txtPreco;
	@FXML
	private TextField txtFk_aluno;

	private Stage palcoDialogo;

	private Curso curso;

	@FXML
	private void initialize() {

	}

	public void setPalcoDialogo(Stage palcoDialogo) {
		this.palcoDialogo = palcoDialogo;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
		txtId.setText(String.valueOf(curso.getId()));
		txtCnome.setText(curso.getNome());
		txtRequisito.setText(curso.getRequisito());
		txtCargaHoraria.setText(String.valueOf(curso.getCarga_horaria()));
		txtPreco.setText(String.valueOf(curso.getPreco()));
		txtFk_aluno.setText(String.valueOf(curso.getFk_aluno()));
	}

	@FXML
	private void cliqueOk() {
		// pessoa.setCodigo(Integer.parseInt(txtCodigo.getText()));
		curso.setNome(txtCnome.getText());
		curso.setRequisito(txtRequisito.getText());

		// insere os dados no banco de dados
		CursoDAO adao = new CursoDAO();
		if (curso.getId() > 0) {
			adao.alterar(curso);
		} else {
			adao.inserir(curso);
		}
		adao.listar();

		palcoDialogo.close();
	}

	@FXML
	private void cliqueCancelar() {
		palcoDialogo.close();
	}

}
